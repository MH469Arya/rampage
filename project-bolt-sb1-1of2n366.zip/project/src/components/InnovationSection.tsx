import React from 'react';
import { Lightbulb, Wind, Sun, Droplets, Recycle } from 'lucide-react';

const TechCard = ({ icon: Icon, title, description, color }) => {
  return (
    <div className={`bg-white rounded-xl shadow-md overflow-hidden border-t-4 ${color}`}>
      <div className="p-6">
        <div className="flex items-center mb-4">
          <Icon className="h-6 w-6 text-gray-700 mr-3" />
          <h3 className="text-xl font-semibold text-gray-800">{title}</h3>
        </div>
        <p className="text-gray-600">{description}</p>
      </div>
    </div>
  );
};

const InnovationSection = () => {
  const technologies = [
    {
      icon: Wind,
      title: "Advanced Renewable Energy",
      description: "Next-generation solar, wind, and energy storage technologies that dramatically increase efficiency and reduce costs.",
      color: "border-blue-500"
    },
    {
      icon: Recycle,
      title: "Circular Economy Systems",
      description: "Innovative approaches to product design, manufacturing, and waste management that eliminate waste and pollution.",
      color: "border-green-500"
    },
    {
      icon: Droplets,
      title: "Carbon Capture & Utilization",
      description: "Technologies that remove carbon dioxide from the atmosphere and transform it into valuable products.",
      color: "border-purple-500"
    },
    {
      icon: Sun,
      title: "Smart Grid Technologies",
      description: "Intelligent energy distribution systems that optimize renewable energy use and improve grid resilience.",
      color: "border-amber-500"
    }
  ];

  return (
    <section id="innovation" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row gap-12">
          <div className="md:w-2/5">
            <div className="sticky top-24">
              <div className="p-4 bg-blue-100 rounded-full w-fit mb-4">
                <Lightbulb className="h-6 w-6 text-blue-600" />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-gray-800">Innovative Technologies</h2>
              <p className="text-xl text-gray-600 mb-8">
                Leveraging cutting-edge technology and innovation is essential to developing effective climate solutions at the pace and scale required.
              </p>
              <div className="relative h-64 rounded-xl overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1074&q=80" 
                  alt="Innovative technology for climate solutions" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                  <p className="text-white p-4 text-sm">
                    Innovation drives climate solutions forward
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="md:w-3/5">
            <div className="grid grid-cols-1 gap-8">
              {technologies.map((tech, index) => (
                <TechCard 
                  key={index}
                  icon={tech.icon}
                  title={tech.title}
                  description={tech.description}
                  color={tech.color}
                />
              ))}
              
              <div className="bg-gradient-to-r from-blue-500 to-emerald-500 rounded-xl shadow-md p-8 text-white">
                <h3 className="text-2xl font-semibold mb-4">The Innovation Imperative</h3>
                <p className="mb-4">
                  Climate change presents unprecedented challenges that cannot be solved with existing technologies and approaches alone. Innovation is not optional—it's essential.
                </p>
                <p>
                  By investing in research, development, and deployment of breakthrough technologies, we can accelerate the transition to a sustainable, low-carbon future while creating new economic opportunities.
                </p>
              </div>
              
              <div className="relative h-80 rounded-xl overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1569012871812-f38ee64cd54c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80" 
                  alt="Renewable energy technology" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                  <p className="text-white p-6 text-lg font-medium">
                    Technology enables us to reimagine our relationship with energy and resources
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default InnovationSection;