import React, { useState } from 'react';
import { Leaf, Menu, X } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md shadow-sm">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Leaf className="h-6 w-6 text-emerald-500" />
          <span className="font-bold text-xl text-emerald-700">ClimateForward</span>
        </div>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:flex space-x-8">
          <a href="#solutions" className="text-gray-700 hover:text-emerald-600 transition-colors">Solutions</a>
          <a href="#innovation" className="text-gray-700 hover:text-emerald-600 transition-colors">Innovation</a>
          <a href="#equity" className="text-gray-700 hover:text-emerald-600 transition-colors">Equity</a>
          <a href="#action" className="text-gray-700 hover:text-emerald-600 transition-colors">Take Action</a>
        </nav>
        
        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-gray-700"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X /> : <Menu />}
        </button>
      </div>
      
      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-md">
          <div className="container mx-auto px-4 py-4 flex flex-col space-y-4">
            <a 
              href="#solutions" 
              className="text-gray-700 hover:text-emerald-600 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Solutions
            </a>
            <a 
              href="#innovation" 
              className="text-gray-700 hover:text-emerald-600 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Innovation
            </a>
            <a 
              href="#equity" 
              className="text-gray-700 hover:text-emerald-600 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Equity
            </a>
            <a 
              href="#action" 
              className="text-gray-700 hover:text-emerald-600 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Take Action
            </a>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;