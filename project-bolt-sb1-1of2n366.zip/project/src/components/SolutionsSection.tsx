import React from 'react';
import { Leaf, Globe, BarChart3, Building2, Shield } from 'lucide-react';

const SolutionCard = ({ icon: Icon, title, description }) => {
  return (
    <div className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow p-6 flex flex-col h-full">
      <div className="p-3 bg-emerald-100 rounded-full w-fit mb-4">
        <Icon className="h-6 w-6 text-emerald-600" />
      </div>
      <h3 className="text-xl font-semibold mb-3 text-gray-800">{title}</h3>
      <p className="text-gray-600 flex-grow">{description}</p>
    </div>
  );
};

const SolutionsSection = () => {
  const solutions = [
    {
      icon: Leaf,
      title: "Emission Reduction",
      description: "Implementing carbon capture technologies, renewable energy transitions, and sustainable transportation systems to drastically cut greenhouse gas emissions."
    },
    {
      icon: Globe,
      title: "Global Cooperation",
      description: "Fostering international partnerships and policy frameworks that align climate goals across borders and facilitate knowledge sharing."
    },
    {
      icon: BarChart3,
      title: "Scalable Solutions",
      description: "Developing climate interventions that can be implemented at various scales, from local communities to global systems, maximizing impact."
    },
    {
      icon: Building2,
      title: "Sustainable Infrastructure",
      description: "Building climate-resilient cities and infrastructure that minimize environmental impact while supporting growing populations."
    },
    {
      icon: Shield,
      title: "Climate Resilience",
      description: "Enhancing adaptive capacity of communities and ecosystems to withstand and recover from climate-related disruptions and extreme weather events."
    }
  ];

  return (
    <section id="solutions" className="py-20 bg-gradient-to-br from-emerald-50 to-blue-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Scalable Climate Solutions</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Effective climate action requires solutions that can be implemented at scale to create meaningful global impact.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {solutions.map((solution, index) => (
            <SolutionCard 
              key={index}
              icon={solution.icon}
              title={solution.title}
              description={solution.description}
            />
          ))}
        </div>
        
        <div className="mt-16 bg-white rounded-xl shadow-md p-8 border-l-4 border-emerald-500">
          <h3 className="text-2xl font-semibold mb-4 text-gray-800">Why Scalability Matters</h3>
          <p className="text-gray-600 mb-4">
            Climate change is a global challenge that requires solutions capable of creating impact at a planetary scale. Scalable approaches ensure that successful interventions can be replicated and expanded to meet the urgency and magnitude of the climate crisis.
          </p>
          <p className="text-gray-600">
            By focusing on solutions that can grow from local pilots to global implementation, we maximize our collective ability to reduce emissions, build resilience, and create sustainable systems that work for communities worldwide.
          </p>
        </div>
      </div>
    </section>
  );
};

export default SolutionsSection;