import React from 'react';
import { ArrowRight, Trees } from 'lucide-react';

const ActionCard = ({ title, description, actionText }) => {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden h-full flex flex-col">
      <div className="p-6 flex-grow">
        <h3 className="text-xl font-semibold mb-3 text-gray-800">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
      </div>
      <div className="px-6 pb-6">
        <button className="text-emerald-600 font-medium flex items-center hover:text-emerald-700 transition-colors">
          {actionText} <ArrowRight className="h-4 w-4 ml-1" />
        </button>
      </div>
    </div>
  );
};

const ActionSection = () => {
  const actions = [
    {
      title: "Individual Action",
      description: "Make sustainable choices in your daily life, from reducing energy consumption to choosing low-carbon transportation options.",
      actionText: "Explore personal actions"
    },
    {
      title: "Community Engagement",
      description: "Join or start local climate initiatives, participate in community resilience planning, and support climate education.",
      actionText: "Find local groups"
    },
    {
      title: "Policy Advocacy",
      description: "Advocate for climate policies at all levels of government, from local renewable energy mandates to international climate agreements.",
      actionText: "Learn about advocacy"
    },
    {
      title: "Business Leadership",
      description: "Support businesses committed to sustainability, and if you're a business leader, implement climate-friendly practices.",
      actionText: "Discover business solutions"
    }
  ];

  return (
    <section id="action" className="py-20 bg-gradient-to-br from-emerald-100 to-emerald-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="p-4 bg-emerald-100 rounded-full w-fit mx-auto mb-4">
            <Trees className="h-6 w-6 text-emerald-600" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Take Action Today</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Everyone has a role to play in addressing climate change. Here are ways you can contribute to climate solutions.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {actions.map((action, index) => (
            <ActionCard 
              key={index}
              title={action.title}
              description={action.description}
              actionText={action.actionText}
            />
          ))}
        </div>
        
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="p-8 lg:p-12">
              <h3 className="text-2xl font-semibold mb-4 text-gray-800">Join the Movement</h3>
              <p className="text-gray-600 mb-6">
                Subscribe to our newsletter to stay informed about climate solutions and opportunities to get involved. Together, we can create a sustainable future for all.
              </p>
              <form className="space-y-4">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                    placeholder="your@email.com"
                  />
                </div>
                <div>
                  <label htmlFor="interests" className="block text-sm font-medium text-gray-700 mb-1">
                    Areas of Interest
                  </label>
                  <select
                    id="interests"
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  >
                    <option value="">Select your interests</option>
                    <option value="renewable-energy">Renewable Energy</option>
                    <option value="sustainable-agriculture">Sustainable Agriculture</option>
                    <option value="climate-policy">Climate Policy</option>
                    <option value="community-resilience">Community Resilience</option>
                  </select>
                </div>
                <button
                  type="submit"
                  className="w-full px-6 py-3 bg-emerald-600 text-white rounded-md font-medium hover:bg-emerald-700 transition-colors"
                >
                  Subscribe
                </button>
              </form>
            </div>
            <div className="relative h-96 lg:h-auto">
              <img 
                src="https://images.unsplash.com/photo-1552799446-159ba9523315?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80" 
                alt="People working together on climate solutions" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                <p className="text-white p-6 text-lg font-medium">
                  Together, we can create a sustainable and equitable future
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ActionSection;