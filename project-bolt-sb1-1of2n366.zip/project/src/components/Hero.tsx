import React from 'react';
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative py-20 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 z-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-emerald-400 to-blue-500"></div>
        <div className="absolute top-0 left-0 w-full h-full">
          {[...Array(20)].map((_, i) => (
            <div 
              key={i}
              className="absolute rounded-full bg-white"
              style={{
                width: `${Math.random() * 300 + 50}px`,
                height: `${Math.random() * 300 + 50}px`,
                top: `${Math.random() * 100}%`,
                left: `${Math.random() * 100}%`,
                opacity: Math.random() * 0.5,
              }}
            ></div>
          ))}
        </div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent">
            Climate Solutions for a Sustainable Future
          </h1>
          <p className="text-xl md:text-2xl text-gray-700 mb-8 leading-relaxed">
            Addressing climate change requires scalable, inclusive, and innovative solutions that reduce emissions, enhance resilience, and ensure equitable access to sustainable practices by leveraging technology and overcoming fragmented global efforts.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a 
              href="#solutions" 
              className="px-8 py-3 bg-emerald-600 text-white rounded-full font-medium hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2"
            >
              Explore Solutions
              <ArrowRight className="h-5 w-5" />
            </a>
            <a 
              href="#action" 
              className="px-8 py-3 bg-white text-emerald-600 border border-emerald-600 rounded-full font-medium hover:bg-emerald-50 transition-colors"
            >
              Take Action
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;