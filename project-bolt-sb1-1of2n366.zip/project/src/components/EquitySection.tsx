import React from 'react';
import { Users, Globe, Shield } from 'lucide-react';

const EquitySection = () => {
  return (
    <section id="equity" className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <div className="p-4 bg-purple-100 rounded-full w-fit mx-auto mb-4">
            <Users className="h-6 w-6 text-purple-600" />
          </div>
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-800">Ensuring Equitable Access</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Climate solutions must be accessible to all communities, especially those most vulnerable to climate impacts.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            <div className="relative h-64">
              <img 
                src="https://images.unsplash.com/photo-1532629345422-7515f3d16bb6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80" 
                alt="Community solar project" 
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-8">
              <h3 className="text-2xl font-semibold mb-4 text-gray-800">Climate Justice</h3>
              <p className="text-gray-600 mb-4">
                Climate change disproportionately affects vulnerable communities who have contributed least to the problem. Climate justice recognizes these inequities and works to ensure that climate solutions don't exacerbate existing disparities.
              </p>
              <p className="text-gray-600">
                By centering equity in our approach, we can develop solutions that address both environmental and social challenges, creating a more just and sustainable future for all.
              </p>
            </div>
          </div>
          
          <div className="flex flex-col gap-8">
            <div className="bg-white rounded-xl shadow-md p-8 border-l-4 border-purple-500">
              <div className="flex items-center mb-4">
                <Globe className="h-6 w-6 text-purple-600 mr-3" />
                <h3 className="text-xl font-semibold text-gray-800">Global Cooperation</h3>
              </div>
              <p className="text-gray-600">
                Addressing climate change requires unprecedented global cooperation. Developed nations must support developing countries with technology transfer, capacity building, and climate finance to enable a just transition to low-carbon economies.
              </p>
            </div>
            
            <div className="bg-white rounded-xl shadow-md p-8 border-l-4 border-blue-500">
              <div className="flex items-center mb-4">
                <Shield className="h-6 w-6 text-blue-600 mr-3" />
                <h3 className="text-xl font-semibold text-gray-800">Resilient Communities</h3>
              </div>
              <p className="text-gray-600">
                Building resilience in vulnerable communities is essential for climate adaptation. This includes improving infrastructure, diversifying livelihoods, and strengthening social safety nets to help communities withstand and recover from climate impacts.
              </p>
            </div>
            
            <div className="bg-gradient-to-r from-purple-500 to-blue-500 rounded-xl shadow-md p-8 text-white">
              <h3 className="text-2xl font-semibold mb-4">Equity Principles</h3>
              <ul className="space-y-3">
                <li className="flex items-start">
                  <span className="bg-white text-purple-600 rounded-full p-1 mr-3 mt-1">
                    <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </span>
                  <span>Inclusive decision-making that involves affected communities</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-white text-purple-600 rounded-full p-1 mr-3 mt-1">
                    <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </span>
                  <span>Fair distribution of benefits and burdens of climate action</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-white text-purple-600 rounded-full p-1 mr-3 mt-1">
                    <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </span>
                  <span>Recognition of historical responsibilities and differentiated capabilities</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-white text-purple-600 rounded-full p-1 mr-3 mt-1">
                    <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </span>
                  <span>Ensuring access to clean energy, water, and sustainable livelihoods</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EquitySection;