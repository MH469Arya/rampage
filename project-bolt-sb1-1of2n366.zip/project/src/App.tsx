import React from 'react';
import { 
  Leaf, 
  Globe, 
  Users, 
  Lightbulb, 
  Shield, 
  Recycle, 
  BarChart3, 
  Building2, 
  Trees, 
  Wind, 
  Droplets, 
  Sun, 
  ArrowRight 
} from 'lucide-react';
import Header from './components/Header';
import Hero from './components/Hero';
import SolutionsSection from './components/SolutionsSection';
import InnovationSection from './components/InnovationSection';
import EquitySection from './components/EquitySection';
import ActionSection from './components/ActionSection';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-blue-50">
      <Header />
      <Hero />
      <SolutionsSection />
      <InnovationSection />
      <EquitySection />
      <ActionSection />
      <Footer />
    </div>
  );
}

export default App;